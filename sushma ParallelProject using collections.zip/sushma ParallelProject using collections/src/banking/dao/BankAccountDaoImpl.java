package banking.dao;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;

public class BankAccountDaoImpl implements BankAccountDao{
  static List<BankAccount> list=new ArrayList<BankAccount>();
  static HashMap<Double,Double> map=new HashMap<Double,Double>();
  static BankAccount account =new BankAccount();
	@Override
	public void CreateAccount(BankAccount bankaccount) {
		// TODO Auto-generated method stub
		list.add(bankaccount);
		System.out.println("Account Created");
		System.out.println("list data  "+list);
		
	}
	@Override
	public double displayBalance(int accountNo) {
		// TODO Auto-generated method stub
		double balance = 0;
	   System.out.println("show balance ");
	   for(int i=0;i<list.size();i++)
	   {
		   int k=list.get(i).getAccountNo();
		   if(k==accountNo)
		   {
			   balance=list.get(i).getAccountBalance();
		   }
	   }
	 //  BankAccount account=list.get(accountNo);
	  // System.out.println(account);
	     return balance;//account.getAccountBalance();
	}
	@Override
	public void deposit(int accountNo, double amount) {
		// TODO Auto-generated method stub
		double currBalance=0;
		System.out.println("deposit");
		 for(int i=0;i<list.size();i++)
		   {
			   int k=list.get(i).getAccountNo();
			   if(k==accountNo)
			   {
				   double balance=list.get(i).getAccountBalance();
				   currBalance=amount+balance;
				   list.get(i).setAccountBalance(currBalance);
			   }
		   }
	}
	@Override
	public void withdraw(int accountNo, double amount) {
		// TODO Auto-generated method stub
		System.out.println("withdraw");
		double currBalance=0;
		 for(int i=0;i<list.size();i++)
		   {
			   int k=list.get(i).getAccountNo();
			   if(k==accountNo)
			   {
				   double balance=list.get(i).getAccountBalance();
				   currBalance=balance-amount;
				   list.get(i).setAccountBalance(currBalance);
			   }
		   }
		
	}
	@Override
	public void fundTransfer(int accountNo1, int accountNo2, double amount) {
		// TODO Auto-generated method stub
		System.out.println("fund transfer");
		double currBalance=0;
		for(int i=0;i<list.size();i++)
		{
			int k=list.get(i).getAccountNo();
			if(k==accountNo1)
			{
				double balance=list.get(i).getAccountBalance();
				currBalance=balance-amount;
				list.get(i).setAccountBalance(currBalance);
			}
			else if(k==accountNo2)
			{
				double balance=list.get(i).getAccountBalance();
				currBalance=balance+amount;
				list.get(i).setAccountBalance(currBalance);
			}
		}
	}
	@Override
	public Map<Double,Double> printTransactions() {
		// TODO Auto-generated method stub
		for(int i=0;i<list.size();i++)
		{
			map.put(list.get(i).getAccountBalance(), list.get(i).getInitialBalance());
		}
		return map;
	}

	
	
	
}
